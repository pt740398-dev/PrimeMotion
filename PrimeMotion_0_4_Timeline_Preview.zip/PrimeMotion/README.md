# Prime Motion 0.4 — Editing Workspace Milestone

Original Android editor project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Implemented in this milestone
- Dark mobile editing workspace and project settings.
- Import video and audio from Android's document picker.
- Video preview with Media3 ExoPlayer.
- Read the imported video's actual duration after the player becomes ready.
- Timeline playhead seeks the preview to the selected time.
- Video/audio/text/shape layer entries, selection and removal.
- Basic split and trim metadata controls.

## Not implemented yet (do not treat these controls as finished)
- Frame-accurate non-destructive clip editing and timeline drag/reorder.
- Actual effects rendering (Glow, Blur, Shake, color grading), masks and blending.
- Keyframes and graph editor.
- Audio mixing and waveform.
- MP4 export/rendering.

This is an original project and an incremental development build, not a complete Alight Motion replacement. It uses an independent interface and implementation.

## Build with GitHub Actions
1. Upload the contents of this folder to the root of your `PrimeMotion` GitHub repository.
2. Keep `.github/workflows/android-apk.yml` at that exact path.
3. Open **Actions → Prime Motion APK Build → Run workflow**.
4. When the run succeeds, open its **Artifacts** section and download `Prime-Motion-0.4-APK`.

Build environment: JDK 17, Gradle 8.9, Android Gradle Plugin as declared by the project.
