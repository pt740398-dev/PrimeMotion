# PRIME MOTION — Foundation 0.1.0

Original Android editor foundation using Kotlin, Jetpack Compose and AndroidX Media3.

## Included
- PRIME MOTION dark/cyan identity and vector launcher icon.
- Project-name field.
- Android video picker.
- Real video playback preview using Media3 ExoPlayer.
- Starter timeline workspace.
- GitHub Actions workflow to build and upload a debug APK.

## Not yet implemented
This is a working foundation, not a finished Alight Motion-style editor. Timeline clip editing, trim/split, keyframes, effects, audio mixing, project saving and MP4 export are future development phases. Do not treat the timeline bar as a functional editing timeline yet.

## Build using only a phone
1. Create a new GitHub repository.
2. Upload all files and folders from this project, keeping their paths.
3. Open the repository's Actions tab.
4. Choose "Build Prime Motion APK" and tap "Run workflow".
5. Open the completed workflow run and download the "Prime-Motion-debug-apk" artifact.
6. Extract the downloaded artifact ZIP to find app-debug.apk.

Requires Android SDK 35 and JDK 17 on the GitHub runner. The generated debug APK is for testing.
