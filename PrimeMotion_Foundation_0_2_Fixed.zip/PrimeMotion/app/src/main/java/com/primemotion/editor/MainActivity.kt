package com.primemotion.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Ink = Color(0xFF080A12)
private val Panel = Color(0xFF141927)
private val Cyan = Color(0xFF00E5FF)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { PrimeMotionHome() }
 }
}

@Composable
private fun PrimeMotionHome() {
 var selectedVideo by remember { mutableStateOf<Uri?>(null) }
 var projectName by remember { mutableStateOf("My First Project") }
 val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
  selectedVideo = uri
 }
 MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Ink, surface = Panel)) {
  Column(Modifier.fillMaxSize().background(Ink).padding(16.dp)) {
   Row(verticalAlignment = Alignment.CenterVertically) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
     Text("PM", color = Cyan, fontSize = 22.sp, modifier = Modifier.padding(12.dp))
    }
    Spacer(Modifier.width(12.dp))
    Column {
     Text("PRIME MOTION", color = Color.White, fontSize = 20.sp)
     Text("Mobile video editor", color = Color.LightGray, fontSize = 12.sp)
    }
   }
   Spacer(Modifier.height(20.dp))
   OutlinedTextField(projectName, { projectName = it }, label = { Text("Project name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
   Spacer(Modifier.height(14.dp))
   Text("PREVIEW", color = Cyan, fontSize = 12.sp)
   Spacer(Modifier.height(8.dp))
   Surface(Modifier.fillMaxWidth().weight(1f), color = Panel, shape = RoundedCornerShape(16.dp)) {
    if (selectedVideo == null) {
     Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
      Text("Your video preview", color = Color.White, fontSize = 18.sp)
      Spacer(Modifier.height(8.dp))
      Text("Import a video to start", color = Color.LightGray)
      Spacer(Modifier.height(14.dp))
      Button(onClick = { picker.launch(arrayOf("video/*")) }) { Text("Import video") }
     }
    } else {
     PrimeVideoPreview(selectedVideo!!)
    }
   }
   Spacer(Modifier.height(14.dp))
   Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.weight(1f)) { Text("Add video") }
    OutlinedButton(onClick = { selectedVideo = null }, modifier = Modifier.weight(1f)) { Text("Clear") }
   }
   Spacer(Modifier.height(18.dp))
   Text("TIMELINE FOUNDATION", color = Cyan, fontSize = 12.sp)
   Spacer(Modifier.height(8.dp))
   Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
    Column(Modifier.padding(14.dp)) {
     Text("Video track", color = Color.White)
     Spacer(Modifier.height(10.dp))
     Box(Modifier.fillMaxWidth().height(12.dp).background(Color(0xFF293247), RoundedCornerShape(8.dp))) {
      Box(Modifier.fillMaxWidth(.38f).fillMaxHeight().background(Cyan, RoundedCornerShape(8.dp)))
     }
     Spacer(Modifier.height(8.dp))
     Text("Timeline editing is the next development phase", color = Color.LightGray, fontSize = 11.sp)
    }
   }
   Spacer(Modifier.height(8.dp))
   Text("Foundation 0.1.0", color = Color.Gray, fontSize = 10.sp)
  }
 }
}

@Composable
private fun PrimeVideoPreview(uri: Uri) {
 val context = androidx.compose.ui.platform.LocalContext.current
 val exoPlayer = remember(uri) {
  ExoPlayer.Builder(context).build().apply {
   setMediaItem(MediaItem.fromUri(uri))
   prepare()
   playWhenReady = false
  }
 }
 DisposableEffect(exoPlayer) { onDispose { exoPlayer.release() } }
 AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = exoPlayer; useController = true } },
  update = { it.player = exoPlayer }, modifier = Modifier.fillMaxSize())
}
