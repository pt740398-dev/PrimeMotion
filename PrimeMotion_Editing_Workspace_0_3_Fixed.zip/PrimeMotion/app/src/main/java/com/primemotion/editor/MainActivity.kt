package com.primemotion.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.UUID

private val Ink = Color(0xFF10121B)
private val Panel = Color(0xFF191D2A)
private val Panel2 = Color(0xFF23283A)
private val Cyan = Color(0xFF00E6B0)
private val Muted = Color(0xFF9AA2B5)

private data class EditLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String,
    val uri: Uri? = null,
    val duration: Float = 10f,
    val start: Float = 0f
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeMotionEditor() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrimeMotionEditor() {
    var projectName by remember { mutableStateOf("New Project") }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    val layers = remember { mutableStateListOf<EditLayer>() }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var addPanel by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("Media") }
    var showSettings by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var projectRatio by remember { mutableStateOf("1:1") }
    var projectFps by remember { mutableStateOf("30 fps") }
    var projectResolution by remember { mutableStateOf("1080p") }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { }.onSuccess {
                videoUri = uri
                val item = EditLayer(name = "Video ${layers.count { it.kind == "VIDEO" } + 1}", kind = "VIDEO", uri = uri, duration = 30f)
                layers.add(item); selectedId = item.id
            }
        }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            audioUri = uri
            val item = EditLayer(name = "Audio ${layers.count { it.kind == "AUDIO" } + 1}", kind = "AUDIO", uri = uri, duration = 30f)
            layers.add(item); selectedId = item.id
        }
    }
    val selected = layers.firstOrNull { it.id == selectedId }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Ink, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Ink)) {
            Row(Modifier.fillMaxWidth().height(54.dp).background(Panel).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("‹", color = Color.White, fontSize = 30.sp, modifier = Modifier.clickable { addPanel = false })
                Spacer(Modifier.width(12.dp))
                TextField(projectName, { projectName = it }, modifier = Modifier.weight(1f), singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Panel, unfocusedContainerColor = Panel, focusedIndicatorColor = Cyan, unfocusedIndicatorColor = Color.Transparent))
                Text("⚙", color = Color.White, fontSize = 23.sp, modifier = Modifier.clickable { showSettings = true }.padding(horizontal = 10.dp))
                Text("⇧", color = Cyan, fontSize = 25.sp, modifier = Modifier.clickable { showExport = true })
            }

            Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black), contentAlignment = Alignment.Center) {
                if (videoUri != null) {
                    PrimeVideoPreview(videoUri!!)
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("PRIME MOTION", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Preview canvas", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { videoPicker.launch(arrayOf("video/*")) }) { Text("Import video", color = Cyan) }
                    }
                }
            }

            Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 10.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                    ToolButton("↤", "Start") { playhead = 0f }
                    ToolButton("−", "Back 1s") { playhead = (playhead - 1f).coerceAtLeast(0f) }
                    ToolButton("＋", "Forward 1s") { playhead = (playhead + 1f).coerceAtMost(60f) }
                    ToolButton("▣", "Add layer") { addPanel = true }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(formatTime(playhead), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Slider(value = playhead, onValueChange = { playhead = it }, valueRange = 0f..60f, modifier = Modifier.weight(1f))
                    Text("00:60", color = Muted, fontSize = 11.sp)
                }
            }

            Row(Modifier.fillMaxWidth().background(Panel2).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TIMELINE", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${layers.size} layers", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.width(12.dp))
                Text("＋ Add", color = Cyan, modifier = Modifier.clickable { addPanel = true })
            }
            if (layers.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(116.dp).background(Panel), contentAlignment = Alignment.Center) {
                    Text("Add media, audio or text to start editing", color = Muted, fontSize = 12.sp)
                }
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 190.dp).background(Panel), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(layers, key = { it.id }) { layer ->
                        Row(Modifier.fillMaxWidth().background(if (selectedId == layer.id) Color(0xFF263D43) else Panel2, RoundedCornerShape(9.dp)).border(if (selectedId == layer.id) 1.dp else 0.dp, Cyan, RoundedCornerShape(9.dp)).clickable { selectedId = layer.id }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(70.dp)) {
                                Text(layer.kind, color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(layer.name, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box(Modifier.weight(1f).height(30.dp).background(if (layer.kind == "AUDIO") Color(0xFF375B78) else if (layer.kind == "TEXT") Color(0xFF65528B) else Color(0xFF176B65), RoundedCornerShape(5.dp)).clickable { selectedId = layer.id }, contentAlignment = Alignment.CenterStart) {
                                Text("  ${formatTime(layer.start)}  ━━━━━━━━━", color = Color.White, fontSize = 10.sp)
                            }
                            Text("×", color = Color(0xFFFF7185), fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp).clickable { layers.remove(layer); if (selectedId == layer.id) selectedId = layers.lastOrNull()?.id })
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Panel2).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { if (selected != null && selected.duration > 1f) {
                    val left = playhead.coerceIn(0f, selected.duration - 0.5f)
                    val idx = layers.indexOfFirst { it.id == selected.id }
                    if (idx >= 0 && left > 0.2f) {
                        layers[idx] = selected.copy(name = selected.name + " A", duration = left)
                        val right = selected.copy(id = UUID.randomUUID().toString(), name = selected.name + " B", duration = selected.duration - left, start = selected.start + left)
                        layers.add(idx + 1, right); selectedId = right.id
                    }
                } }, modifier = Modifier.weight(1f)) { Text("Split", fontSize = 12.sp) }
                OutlinedButton(onClick = { if (selected != null) { val idx = layers.indexOfFirst { it.id == selected.id }; if (idx >= 0) layers[idx] = selected.copy(start = (selected.start + 1f).coerceAtMost(59f), duration = (selected.duration - 1f).coerceAtLeast(1f)) } }, modifier = Modifier.weight(1f)) { Text("Trim +1s", fontSize = 12.sp) }
                Button(onClick = { addPanel = true }, modifier = Modifier.weight(1f)) { Text("＋ Add", fontSize = 12.sp) }
            }
        }

        if (addPanel) {
            ModalBottomSheet(onDismissRequest = { addPanel = false }, containerColor = Panel2, contentColor = Color.White) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Shape", "Media", "Audio", "Object", "Template", "Text").forEach { tab ->
                        FilterChip(selected = activeTab == tab, onClick = { activeTab = tab }, label = { Text(tab) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Cyan, selectedLabelColor = Ink))
                    }
                }
                when (activeTab) {
                    "Media" -> AddChoice("Import video", "Choose a video from your phone") { videoPicker.launch(arrayOf("video/*")); addPanel = false }
                    "Audio" -> AddChoice("Import audio", "Choose an audio file") { audioPicker.launch(arrayOf("audio/*")); addPanel = false }
                    "Text" -> AddChoice("Add text layer", "Create an editable text layer") {
                        val item = EditLayer(name = "Text layer ${layers.count { it.kind == "TEXT" } + 1}", kind = "TEXT", duration = 8f)
                        layers.add(item); selectedId = item.id; addPanel = false
                    }
                    "Shape" -> AddChoice("Add shape layer", "Create a basic shape layer") {
                        val item = EditLayer(name = "Shape layer ${layers.count { it.kind == "SHAPE" } + 1}", kind = "SHAPE", duration = 8f)
                        layers.add(item); selectedId = item.id; addPanel = false
                    }
                    else -> AddChoice("Add ${activeTab.lowercase()} layer", "Layer placeholder for the next tools phase") {
                        val item = EditLayer(name = "$activeTab layer", kind = activeTab.uppercase(), duration = 8f)
                        layers.add(item); selectedId = item.id; addPanel = false
                    }
                }
                Spacer(Modifier.height(30.dp))
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Project settings") }, text = {
            Column {
                Text("Aspect ratio"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("16:9","9:16","1:1","4:5").forEach { FilterChip(selected = projectRatio == it, onClick = { projectRatio = it }, label = { Text(it) }) } }
                Text("Resolution"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("720p","1080p").forEach { FilterChip(selected = projectResolution == it, onClick = { projectResolution = it }, label = { Text(it) }) } }
                Text("Frame rate"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("30 fps","60 fps").forEach { FilterChip(selected = projectFps == it, onClick = { projectFps = it }, label = { Text(it) }) } }
            }
        }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } })
        if (showExport) AlertDialog(onDismissRequest = { showExport = false }, title = { Text("Export") }, text = { Text("MP4 rendering is the next development phase. Your current project workspace supports adding and arranging layer entries, split and basic trim controls.") }, confirmButton = { TextButton(onClick = { showExport = false }) { Text("OK") } })
    }
}

@Composable
private fun ToolButton(symbol: String, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }.padding(horizontal = 4.dp)) {
        Text(symbol, color = Color.White, fontSize = 23.sp)
        Text(label, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun AddChoice(title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Text("＋", color = Cyan, fontSize = 25.sp)
    }
}

private fun formatTime(seconds: Float): String {
    val total = seconds.toInt().coerceAtLeast(0)
    return "%02d:%02d".format(total / 60, total % 60)
}

@Composable
private fun PrimeVideoPreview(uri: Uri) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val exoPlayer = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(exoPlayer) { onDispose { exoPlayer.release() } }
    AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer; useController = true } },
        update = { it.player = exoPlayer }, modifier = Modifier.fillMaxSize())
}
