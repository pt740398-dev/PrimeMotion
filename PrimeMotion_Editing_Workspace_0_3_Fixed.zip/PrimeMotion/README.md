# PRIME MOTION — Editing Workspace Preview

Original Android editor project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Current milestone
- Dark editing workspace inspired by common mobile motion-editor workflows.
- Video import and playback preview.
- Project name and project settings (aspect ratio, resolution label, frame-rate label).
- Layer list for video, audio, text and shape entries.
- Add video/audio through Android document picker.
- Add text and shape layer entries.
- Select and remove layers.
- Basic timeline playhead, split-layer operation and basic trim control.

## Not yet implemented
- Timeline playback synchronization, drag-to-reorder, precise trim handles and undo/redo.
- Actual visual text/shape compositing in preview.
- Actual effects rendering (blur, glow, shake, color grading), masks, blending, keyframe/graph animation.
- Audio mixing and waveform.
- MP4 export / rendering.

The workspace is a first functional editing milestone, not a complete replacement for Alight Motion. All project assets and implementation are original.

## Build
Use the included GitHub Actions workflow with JDK 17 and Gradle 8.9.
